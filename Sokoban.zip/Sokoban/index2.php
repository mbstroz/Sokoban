<?php 
	date_default_timezone_set('America/New_York');
	//Establish the Local IP and DTS time for hidden form submission
	$remoteIP= @$_SERVER["LOCAL_ADDR"];
	
	$dts = date("Y-m-d H:i:s");
?>
<!doctype html>  

<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ --> 
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
		<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
       Remove this if you use the .htaccess -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">


		<title>NSAG SOKOBAN</title>
		<meta name="description" content="NSAG SOKOBAN">
		<meta name="author" content="Marc B. Stroz">

		<link rel="stylesheet" type="text/css" href="../includes/boilerplate/css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/styles.css" />
		<link rel="stylesheet" type="text/css" href="css/jquery.rating.css" />
        <link rel="stylesheet" type="text/css" href="css/960.css" />
       
		
		 <!-- All JavaScript at the bottom, except for Modernizr which enables HTML5 elements & feature detects -->
		<script src="../includes/boilerplate/js/libs/modernizr-1.6.min.js"></script>


	</head>
	<body>
        <div id="header" class="container_12">
        	<div id="head" class="grid_12 alpha">
                <header>
                    <hgroup>
                        <h2>NSAG SOKOBAN</h2>
                    </hgroup>
                                   					
                </header>
            </div>
            <div class="grid_12 alpha">        
                <div id="menu">
                    <nav id=global>
                        <ul>
                            <li><a href=/wccs name=home>HOME</a></li>
                            <li><a href=#admin name=admin>ADMIN</a></li>
                            <li><a href="#about" name=modal>ABOUT</a></li>
                        </ul>
                    </nav>
                 </div>
			</div>
        </div>
                        
        
        <div id="content" class="container_12">
        	<div id="left" class="grid_9 ">
            	<article>
                    <header>
                        <h1>Current Orders In-Bound</h1>
                        <div class="comments">38</div>
                    </header>
                    
                    <footer>
                        <span class="newLine"><em>Tags:</em> <a href="#" class="tags">DELL</a><a href="#" class="tags">Motorolla</a><a href="#" class="tags">CISCO</a></span>
                        
                    </footer>
                </article>
                <article>
                    <header>
                        <h1>Heading to NSAG</h1>
                        <div class="comments">5</div>
                    </header>
                   Heading to NSAG
                    <footer>
                        <span class="newLine"><em>Tags:</em> <a href="#" class="tags">DELL</a><a href="#" class="tags">Motorolla</a><a href="#" class="tags">CISCO</a></span>
                        
                    </footer>
                </article>
                <article>
                    <header>
                        <h1>Heading to Whitelaw</h1>
                        <div class="comments">50</div>
                    </header>
                    
                    <footer>
                        <span class="newLine"><em>Tags:</em> <a href="#" class="tags">DELL</a><a href="#" class="tags">Motorolla</a><a href="#" class="tags">CISCO</a></span>
                        
                    </footer>
                </article>
            </div>
        
       	  <div id="right" class="grid_3 ">
           	   <aside>
                  <section>
                      <h1>WAREHOUSE</h1>
                      <ul id="inTouch">
                          <li><span class="warehouse">12345</span> <a href="#">Warehouse</a> Items</li>
                          <li><span class="rss">4321</span> <a href="#">Ordered</a> Items</li>
                      </ul>
                  </section>
                    
                  <nav>
                      <h1>Quick Links</h1>
                      <ul class="links">
                          <li><a href="#">Warehouse Items</a></li>
                          <li><a href="#">Procured Items</a></li>
                          <li><a href="#">Vendor List</a></li>
                          <li><a href="#">GSA Accounts</a></li>
                      </ul>
                  </nav>
           	  </aside>           	
          </div>
        
        </div>

        <div id="footer" class="container_12">
			<div id="footer" class="grid_12 ">
            	<p class="copyright">
                	I AM A FOOTER
                </p>
            	<div style="display:none" class=success>Success Message</div>
            </div>
        </div>

	  <!--
                	 -->

	  <!-- Javascript at the bottom for fast page loading -->

	  <!-- Grab Google CDN's jQuery. fall back to local if necessary 
	  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.js"></script>-->

	  <script>!window.jQuery && document.write(unescape('%3Cscript src="../includes/boilerplate/js/libs/jquery-1.4.2.js"%3E%3C/script%3E'))</script>
	  
	  
	  <!-- scripts concatenated and minified via ant build script-->
	  <script src="js/plugins.js"></script>
	  <script src="js/script.js"></script>
	  <script src="js/jquery.rating.pack.js"></script>
	  <script src="js/jquery.simplemodal.1.4.1.min.js"></script>
       <script src="../includes/flexigrid/flexigrid.pack.js"></script>
	  
	  <script type="text/javascript" language="javascript">		
		$(document).ready(function(){   
		  $("#formsubmit").click(function() {   
		   // we want to store the values from the form input box, then send via ajax below  			
			var post = $('#submit').serialize();
				$.ajax({   
				   type: "POST",   
				   url: "ajax.php", 
				   data: post,
				   success: function(){   
					   $('#formsubmit').hide(function(){$('div.success').fadeIn();});   
		 
				   }   
			   });   
		   return false;   
			});   
		}); 

		$(document).ready(function() {	
			//select all the a tag with name equal to modal
			$('a[name=modal]').click(function(e) {
				$.modal("<span style='text-align:center;'><pre>NSAG SOKOBAN<br />Sokoban (warehouse keeper) is a type of transport puzzle,<br />in which the player pushes boxes around a maze, viewed from above, and<br />tries to put them in predetermined areas<br /><br />Programmers: Marc Stroz<br />Eric Harrison<br />Andrew Sullivan<br />Date: 02/16/2011</pre></span>");
			});		
			
			$.extend($.modal.defaults, {
			closeClass: "modalClose",
			closeHTML: "<a href='#' style='color:red;'>Close</a>",
			opacity: 80,
			overlayCss: {backgroundColor: "#FFFFFC"},
			height:600,
			width: 600,
			maxWidth: 600
			});
	
		});

	</script>
	  <!-- end concatenated and minified scripts-->
	  
	  
	  <!--[if lt IE 7 ]>
		<script src="js/libs/dd_belatedpng.js"></script>
		<script> DD_belatedPNG.fix('img, .png_bg'); //fix any <img> or .png_bg background-images </script>
	  <![endif]-->

	  
	</body>

</html>